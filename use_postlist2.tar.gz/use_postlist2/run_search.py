import os

cmd_str = """
# on linux
DIR=$(cd `dirname $0`; pwd)
DIR=/export/home/zhangshaohua15/xapian_test/use_postlist
echo ${DIR}
DATA_DIR=${DIR}/data
DATA_PATH=${DIR}/data/data.csv
DB_DIR=${DIR}/db
INDEX_DIR=${DIR}/index

# step3, search_use_weight
echo "[step3] [`date`] search_use_weight ..."
cd ${DIR}/search_use_weight
g++ search.cpp ProfileWeight.cpp  -o search -lxapian -std=c++14 -I.
time ./search ${DB_DIR} t1 10

# step4, search_use_keymaker
echo "[step4] [`date`] search_use_keymaker ..."
cd ${DIR}/search_use_keymaker
g++ search.cpp -o search -lxapian -std=c++14
time ./search ${DB_DIR} t1 10
"""

if __name__ == "__main__":
    os.system(cmd_str)

